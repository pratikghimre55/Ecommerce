import slider as slider
from django.contrib import admin
from .models import Item, Brand, Ad, Slider, Category, Contact,OrderItem,Order

admin.site.register(Item)
admin.site.register(Brand)
admin.site.register(Ad)
admin.site.register(Slider)
admin.site.register(Category)
admin.site.register(Contact)
admin.site.register(OrderItem)
admin.site.register(Order)


# Register your models here.
